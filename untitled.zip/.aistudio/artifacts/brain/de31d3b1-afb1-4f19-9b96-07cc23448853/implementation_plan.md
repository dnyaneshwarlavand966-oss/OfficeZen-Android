# OfficeZen – Complete Offline Android Office Management System

OfficeZen is a native, offline-first Android application designed for end-to-end office administration with a multi-office hierarchy (SJ Office & DIT Office), department groups, selfie-based attendance, attendance-driven salary calculation, daily tea & coffee bookkeeping, physical document handover tracking, office expense logs, PDF report generation, and 6-digit Boss PIN security across all 22 Scheduled Indian Languages + English.

## User Review & Critical Decisions

> [!IMPORTANT]
> The architectural direction and user preferences confirmed in Phase 1:
> - **Default Language**: English with immediate in-app offline switching across all 22 Scheduled Indian Languages (Marathi, Hindi, Gujarati, Tamil, Telugu, Kannada, Bengali, Punjabi, Malayalam, Odia, etc.) + English.
> - **Initial Database State**: Pre-populated with SJ Office and DIT Office, standard departments (Accounts, Staff, Management), and sample employee and transaction records to enable immediate testing across modules.
> - **Selfie Attendance Capture**: Real camera preview & capture support with a graceful emulator/fallback mode (preview simulator & photo capture) ensuring seamless verification in browser streaming emulators as well as real hardware.

---

## 1. Overview & Core Concept

- **What It Does**: Provides an offline-first management hub for business owners ("Boss") and managers to monitor multiple offices (SJ, DIT, and custom units) and departments. Handles employee profiles, daily selfie check-ins, leave approvals, customizable payroll computation (daily/monthly rate, advance deductions, working days), daily tea & coffee tallies with price change protection, signed document custody tracking with photo records, and instant PDF report exports.
- **Target Audience / Persona**: Small and medium business owners, office managers, enterprise team leaders, and administrative supervisors who require a fast, private, offline tool without mandatory cloud accounts.
- **Key Value**: 100% offline autonomy, high-fidelity security via Boss PIN, multi-office granularity, audit traceability, and full regional language accessibility.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Initial Boss Setup & Welcome**: First launch shows a clean onboarding flow to confirm Boss profile and set a 6-digit PIN (default `123456` in demo mode with one-tap quick-access).
2. **Dashboard & Office Selector**: Prominent Office Switcher at the top (`All Offices (Combined)`, `SJ Office`, `DIT Office`, or `+ Add Office`). Quick statistics cards: Active Employees, Today's Present/Absent/Leave, Today's Tea & Coffee, Monthly Expenses, and Pending Approvals.
3. **Selfie Attendance**: Select office & department -> tap employee -> live selfie preview with date/time, employee ID, and office badge watermark -> single tap check-in. Prevents duplicate daily entries. Attendance calendar & boss manual correction with audit logs.
4. **Salary & Payroll**: Select month and office -> automated breakdown based on payable days, configured monthly/daily rate, approved leaves, and advance deductions. Finalize payroll, record payments, and export salary slips to PDF.
5. **Tea & Coffee Quick Counter**: Rapid `+` and `-` counter for morning/evening tea & coffee with real-time bill computation, immutable historical rate snapshot, and 5:00 PM reminder alert.
6. **Documents Handover Log**: Track company files, stamps, or assets handed over to staff or external parties. Capture handover date/time, expected return date, recipient photo, and mark 'Returned' with status history.
7. **Expenses & Reports**: Category-based expense tracking with receipt photo capture. Unified PDF report generator with filters by Office, Department, Employee, and Month.
8. **Settings & 22-Language Switcher**: Instant offline language switcher affecting every label, button, dialog, notification, and generated report string. Boss PIN management and database backup/restore.

### Visual Identity & Theme
- **Aesthetic Direction**: *Executive Dark-Slate & Warm Gold / Cobalt Modern*. Clean, elevated, high-contrast M3 cards with rounded corners (16dp–24dp), crisp borders, and subtle depth elevation.
- **Color Palette**:
  - Primary: Deep Indigo / Cobalt (`#1E3A8A` / `#2563EB`)
  - Accent / Gold: Warm Amber (`#D97706` / `#F59E0B`)
  - Surface Light: `#F8FAFC` (Card `#FFFFFF`)
  - Surface Dark: `#0F172A` (Card `#1E293B`)
  - Success (Present): `#10B981`, Warning (Half-day / Pending): `#F59E0B`, Danger (Absent): `#EF4444`
- **Typography & Hierarchy**: Inter / Outfit modern sans-serif typography hierarchy for clean numeric tables and multi-script legibility across Indian language scripts.
- **Navigation Model**:
  - Bottom Bar (5 Primary Actions): `Home`, `Attendance`, `Employees`, `Salary`, `More`
  - "More" Drawer / Grid: `Tea & Coffee`, `Expenses`, `Documents`, `Leaves`, `Tasks`, `Offices & Groups`, `Reports & PDF`, `Boss Panel`, `Notifications`, `Settings`, `Backup & Restore`
  - Floating Quick-Office Selector in TopAppBar across all screens.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Pure Offline Room Database with In-Memory / Local Blob Support**
  - *Chosen Approach*: Use Android Room Database with foreign keys, cascading indices, and transaction safety. Store photo references in app private storage (`context.filesDir/photos/`).
  - *Why*: User explicitly required 100% offline capability without Firebase, cloud servers, or mandatory internet connections.
- **Decision 2: 22 Indian Scheduled Languages + English Engine**
  - *Chosen Approach*: A centralized `LanguageManager` containing dictionary mappings for all 22 Indian languages (Assamese, Bengali, Bodo, Dogri, Gujarati, Hindi, Kannada, Kashmiri, Konkani, Maithili, Malayalam, Manipuri, Marathi, Nepali, Odia, Punjabi, Sanskrit, Santali, Sindhi, Tamil, Telugu, Urdu) + English, stored locally with instant reactive updates without app restart.
  - *Why*: Ensures 100% offline translation and seamless regional adoption across diverse Indian workforces.
- **Decision 3: Android Native PDFDocument Generation**
  - *Chosen Approach*: Generate standardized PDF reports directly using `android.graphics.pdf.PdfDocument`, allowing instant viewing and Android share sheets (`Intent.ACTION_SEND`).
  - *Why*: Zero third-party cloud dependencies, works completely offline, and renders multi-page tables accurately.
- **Decision 4: Emulator-Friendly CameraX + Fallback Simulator**
  - *Chosen Approach*: CameraX with front-facing camera selector and an automated emulator detection fallback that generates a realistic photo watermark preview when running in headless or virtual container environments.
  - *Why*: Prevents emulator crashes while providing full camera functionality on real physical Android devices.

---

## 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              OfficeZen UI (M3)                              │
│  ┌───────────────┐ ┌────────────────┐ ┌────────────────┐ ┌────────────────┐ │
│  │ TopAppBar &   │ │ BottomNav (5)  │ │ Modules Grid   │ │ Dialogs &      │ │
│  │ Office Switch │ │ Home/Att/Emp/..│ │ Tea/Doc/Exp/.. │ │ Camera Capture │ │
│  └───────┬───────┘ └───────┬────────┘ └───────┬────────┘ └───────┬────────┘ │
└──────────┼─────────────────┼──────────────────┼──────────────────┼──────────┘
           │                 │                  │                  │
┌──────────▼─────────────────▼──────────────────▼──────────────────▼──────────┐
│                             OfficeZen ViewModels                            │
│   DashboardVM  │  AttendanceVM  │  SalaryVM  │  DocumentVM  │  SettingsVM   │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
┌──────────────────────────────────────▼──────────────────────────────────────┐
│                      OfficeZen Unified Repository Layer                     │
│  - Offices & Departments   - Attendance & Selfie   - Salary & Advances      │
│  - Tea & Coffee Logs       - Documents & Tasks     - Expenses & Audit       │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
┌──────────────────────────────────────▼──────────────────────────────────────┐
│                     Room Database (SQLite) & App Storage                    │
│  ┌──────────────────────┐  ┌──────────────────────┐  ┌───────────────────┐  │
│  │ OfficeEntity         │  │ EmployeeEntity       │  │ AttendanceEntity  │  │
│  │ DepartmentEntity     │  │ SalarySettingsEntity │  │ SalaryRecordEntity│  │
│  │ TeaCoffeeEntity      │  │ ExpenseEntity        │  │ DocumentEntity    │  │
│  │ TaskEntity           │  │ LeaveEntity          │  │ AuditLogEntity    │  │
│  └──────────────────────┘  └──────────────────────┘  └───────────────────┘  │
│  Local Filesystem: app private filesDir/photos/ & Encrypted Backup JSON/DB  │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Core Entities & Relationships
1. **OfficeEntity**: `id`, `name` ("SJ Office", "DIT Office"), `code`, `isArchived`, `createdTimestamp`
2. **DepartmentEntity**: `id`, `officeId` (FK), `name` ("Accounts", "Staff", "Management"), `isArchived`
3. **EmployeeEntity**: `id`, `officeId`, `departmentId`, `employeeCode`, `fullName`, `phone`, `designation`, `salaryType` (DAILY / MONTHLY), `baseRate`, `joiningDate`, `photoUri`, `isActive`
4. **AttendanceEntity**: `id`, `employeeId`, `officeId`, `departmentId`, `date` (YYYY-MM-DD), `checkInTime`, `status` (PRESENT, ABSENT, LEAVE, HALF_DAY), `selfieUri`, `isApprovedByBoss`, `remarks`
5. **SalaryRecordEntity**: `id`, `employeeId`, `officeId`, `month` (YYYY-MM), `payableDays`, `grossSalary`, `advancesDeducted`, `otherDeductions`, `netSalary`, `paymentStatus` (PENDING, PAID), `isFinalized`, `paidTimestamp`
6. **TeaCoffeeEntity**: `id`, `officeId`, `date`, `teaCups`, `teaRate`, `coffeeCups`, `coffeeRate`, `totalAmount`, `recordedBy`
7. **DocumentEntity**: `id`, `officeId`, `departmentId`, `documentName`, `personName`, `phone`, `handoverDate`, `expectedReturnDate`, `actualReturnDate`, `status` (PENDING, RETURNED), `photoUri`
8. **ExpenseEntity**: `id`, `officeId`, `category`, `description`, `amount`, `date`, `receiptUri`
9. **TaskEntity**: `id`, `officeId`, `title`, `description`, `assignedEmployeeId`, `dueDate`, `isCompleted`
10. **LeaveEntity**: `id`, `employeeId`, `officeId`, `startDate`, `endDate`, `reason`, `status` (PENDING, APPROVED, REJECTED)
11. **BossSecurityEntity**: `bossName`, `pinHash`, `requirePinOnResume`, `lastLoginTimestamp`
