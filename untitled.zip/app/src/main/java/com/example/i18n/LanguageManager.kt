package com.example.i18n

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class Language(val code: String, val nameInEnglish: String, val nativeName: String)

object LanguageManager {
    val supportedLanguages = listOf(
        Language("en", "English", "English"),
        Language("mr", "Marathi", "मराठी"),
        Language("hi", "Hindi", "हिंदी"),
        Language("gu", "Gujarati", "ગુજરાતી"),
        Language("ta", "Tamil", "தமிழ்"),
        Language("te", "Telugu", "తెలుగు"),
        Language("kn", "Kannada", "ಕನ್ನಡ"),
        Language("bn", "Bengali", "বাংলা"),
        Language("pa", "Punjabi", "ਪੰਜਾਬੀ"),
        Language("ml", "Malayalam", "മലയാളം"),
        Language("or", "Odia", "ଓଡ଼ିଆ"),
        Language("as", "Assamese", "অসমীয়া"),
        Language("ur", "Urdu", "اردو"),
        Language("sa", "Sanskrit", "संस्कृतम्"),
        Language("kok", "Konkani", "कोंकणी"),
        Language("ne", "Nepali", "नेपाली"),
        Language("sd", "Sindhi", "سنڌي"),
        Language("ks", "Kashmiri", "کٲشُر"),
        Language("mai", "Maithili", "मैथिली"),
        Language("sat", "Santali", "ᱥᱟᱱᱛᱟᱲᱤ"),
        Language("brx", "Bodo", "बड़ो"),
        Language("doi", "Dogri", "डोगरी"),
        Language("mni", "Manipuri", "মৈতৈলোন্")
    )

    var currentLanguageCode by mutableStateOf("en")

    private val translations = mapOf(
        "app_name" to mapOf(
            "en" to "OfficeZen", "mr" to "ऑफिसझेन", "hi" to "ऑफिसज़ेन", "gu" to "ઓફિસઝેન",
            "ta" to "ஆஃபிஸ்ஜென்", "te" to "ఆఫీస్ జెన్", "kn" to "ಆಫೀಸ್ ಝೆನ್", "bn" to "অফিসজেন"
        ),
        "dashboard" to mapOf(
            "en" to "Dashboard", "mr" to "डॅशबोर्ड", "hi" to "डैशबोर्ड", "gu" to "ડેશબોર્ડ",
            "ta" to "முகப்புப்பலகை", "te" to "డాష్‌బోర్డ్", "kn" to "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್", "bn" to "ড্যাশবোর্ড"
        ),
        "attendance" to mapOf(
            "en" to "Attendance", "mr" to "हजेरी", "hi" to "उपस्थिति", "gu" to "હાજરી",
            "ta" to "வருகை", "te" to "హాజరు", "kn" to "ಹಾಜರಾತಿ", "bn" to "উপস্থিতি"
        ),
        "employees" to mapOf(
            "en" to "Employees", "mr" to "कर्मचारी", "hi" to "कर्मचारी", "gu" to "કર્મચારીઓ",
            "ta" to "பணியாளர்கள்", "te" to "ఉద్యోగులు", "kn" to "ನೌಕರರು", "bn" to "কর্মচারী"
        ),
        "salary" to mapOf(
            "en" to "Salary", "mr" to "पगार", "hi" to "वेतन", "gu" to "પગાર",
            "ta" to "சம்பளம்", "te" to "జీతం", "kn" to "ವೇತನ", "bn" to "বেতন"
        ),
        "tea_coffee" to mapOf(
            "en" to "Tea & Coffee", "mr" to "चहा व कॉफी", "hi" to "चाय और कॉफी", "gu" to "ચા અને કોફી",
            "ta" to "தேநீர் & காபி", "te" to "టీ & కాఫీ", "kn" to "ಚಹಾ ಮತ್ತು ಕಾಫಿ", "bn" to "চা ও কফি"
        ),
        "expenses" to mapOf(
            "en" to "Expenses", "mr" to "खर्च", "hi" to "खर्चे", "gu" to "ખર્ચાઓ",
            "ta" to "செலவுகள்", "te" to "ఖర్చులు", "kn" to "ವೆಚ್ಚಗಳು", "bn" to "খরচ"
        ),
        "documents" to mapOf(
            "en" to "Documents", "mr" to "कागदपत्रे", "hi" to "दस्तावेज़", "gu" to "દસ્તાવેજો",
            "ta" to "ஆவணங்கள்", "te" to "పత్రాలు", "kn" to "ದಾಖಲೆಗಳು", "bn" to "নথিপত্র"
        ),
        "groups" to mapOf(
            "en" to "Offices & Groups", "mr" to "ऑफिस व विभाग", "hi" to "कार्यालय और विभाग", "gu" to "ઓફિસ અને જૂથો",
            "ta" to "அலுவலகங்கள் & குழுக்கள்", "te" to "కార్యాలయాలు & సమూహాలు", "kn" to "ಕಛೇರಿಗಳು ಮತ್ತು ಇಲಾಖೆಗಳು", "bn" to "অফিস ও বিভাগ"
        ),
        "reports" to mapOf(
            "en" to "Reports", "mr" to "अहवाल", "hi" to "रिपोर्ट्स", "gu" to "અહેવાલો",
            "ta" to "அறிக்கைகள்", "te" to "నివేదికలు", "kn" to "ವರದಿಗಳು", "bn" to "প্রতিবেদন"
        ),
        "boss_panel" to mapOf(
            "en" to "Boss Panel", "mr" to "बॉस पॅनल", "hi" to "बॉस पैनल", "gu" to "બોસ પેનલ",
            "ta" to "பாஸ் குழு", "te" to "బాస్ ప్యానెల్", "kn" to "ಬಾಸ್ ಸಮಿತಿ", "bn" to "বস প্যানেল"
        ),
        "settings" to mapOf(
            "en" to "Settings", "mr" to "सेटिंग्ज", "hi" to "सेटिंग्स", "gu" to "સેટિંગ્સ",
            "ta" to "அமைப்புகள்", "te" to "సెట్టింగ్‌లు", "kn" to "ಸಂಯೋಜನೆಗಳು", "bn" to "সেটিংস"
        ),
        "all_offices" to mapOf(
            "en" to "All Offices", "mr" to "सर्व ऑफिस", "hi" to "सभी कार्यालय", "gu" to "બધી ઓફિસો",
            "ta" to "அனைத்து அலுவலகங்கள்", "te" to "అన్ని కార్యాలయాలు", "kn" to "ಎಲ್ಲಾ ಕಛೇರಿಗಳು", "bn" to "সকল অফিস"
        ),
        "mark_present" to mapOf(
            "en" to "Mark Present", "mr" to "हजर नोंदवा", "hi" to "उपस्थित दर्ज करें", "gu" to "હાજર નોંધો",
            "ta" to "வருகை பதிவு செய்", "te" to "హాజరు వేయండి", "kn" to "ಹಾಜರಾಗಿದ್ದಾರೆ ಎಂದು ದಾಖಲಿಸಿ", "bn" to "উপস্থিত মার্ক করুন"
        ),
        "take_selfie" to mapOf(
            "en" to "Capture Selfie", "mr" to "सेल्फी घ्या", "hi" to "सेल्फी लें", "gu" to "સેલ્ફી લો",
            "ta" to "செல்ஃபி எடுங்கள்", "te" to "సెల్ఫీ తీయండి", "kn" to "ಸೆಲ್ಫಿ ಸೆರೆಹಿಡಿಯಿರಿ", "bn" to "সেলফি তুলুন"
        ),
        "present" to mapOf(
            "en" to "Present", "mr" to "हजर", "hi" to "उपस्थित", "gu" to "હાજર",
            "ta" to "வருகை", "te" to "హాజరు", "kn" to "ಹಾಜರು", "bn" to "উপস্থিত"
        ),
        "absent" to mapOf(
            "en" to "Absent", "mr" to "गैरहजर", "hi" to "अनुपस्थित", "gu" to "ગેરહાજર",
            "ta" to "வரவில்லை", "te" to "గైర్హాజరు", "kn" to "ಗೈರುಹಾಜರು", "bn" to "অনুপস্থিত"
        ),
        "leave" to mapOf(
            "en" to "Leave", "mr" to "रजा", "hi" to "छुट्टी", "gu" to "રજા",
            "ta" to "விடுப்பு", "te" to "సెలవు", "kn" to "ರಜೆ", "bn" to "ছুটি"
        ),
        "today_stats" to mapOf(
            "en" to "Today's Status", "mr" to "आजची स्थिती", "hi" to "आज की स्थिति", "gu" to "આજની સ્થિતિ",
            "ta" to "இன்றைய நிலை", "te" to "నేటి పరిస్థితి", "kn" to "ಇಂದಿನ ಸ್ಥಿತಿ", "bn" to "আজকের অবস্থা"
        ),
        "enter_pin" to mapOf(
            "en" to "Enter 6-Digit Boss PIN", "mr" to "६ अंकी बॉस पिन टाका", "hi" to "६ अंकों का बॉस पिन दर्ज करें", "gu" to "૬ અંકનો બોસ પિન દાખલ કરો",
            "ta" to "6 இலக்க பாஸ் பின்னை உள்ளிடவும்", "te" to "6 అంకెల బాస్ పిన్ నమోదు చేయండి", "kn" to "೬ ಅಂಕಿಯ ಬಾಸ್ ಪಿನ್ ನಮೂದಿಸಿ", "bn" to "৬ সংখ্যার বস পিন লিখুন"
        ),
        "export_pdf" to mapOf(
            "en" to "Export PDF Report", "mr" to "PDF अहवाल तयार करा", "hi" to "PDF रिपोर्ट निर्यात करें", "gu" to "PDF રિપોર્ટ ડાઉનલોડ કરો",
            "ta" to "PDF அறிக்கை ஏற்றுமதி", "te" to "PDF నివేదిక రూపొందించండి", "kn" to "PDF ವರದಿ ರಫ್ತು ಮಾಡಿ", "bn" to "পিডিএফ রিপোর্ট এক্সপোর্ট করুন"
        )
    )

    fun getString(key: String): String {
        val langDict = translations[key] ?: return key
        return langDict[currentLanguageCode] ?: langDict["en"] ?: key
    }
}

// Convenient extension function for composables
fun tr(key: String): String = LanguageManager.getString(key)
