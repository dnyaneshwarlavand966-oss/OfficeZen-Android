package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.i18n.LanguageManager
import com.example.i18n.tr
import com.example.ui.components.BossPinDialog
import com.example.ui.components.LanguageSelectionDialog
import com.example.ui.components.OfficeZenTopBar
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.OfficeZenViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: OfficeZenViewModel = viewModel()
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: OfficeZenViewModel) {
    var currentScreen by remember { mutableStateOf("dashboard") }
    val offices by viewModel.offices.collectAsStateWithLifecycle()
    val selectedOfficeId by viewModel.selectedOfficeId.collectAsStateWithLifecycle()
    val isBossUnlocked by viewModel.isBossUnlocked.collectAsStateWithLifecycle()
    val bossProfile by viewModel.bossProfile.collectAsStateWithLifecycle()

    var showLanguageDialog by remember { mutableStateOf(false) }
    var showBossPinDialog by remember { mutableStateOf(false) }
    var showAddOfficeDialog by remember { mutableStateOf(false) }

    // Sync saved language from boss profile on startup
    LaunchedEffect(bossProfile) {
        bossProfile?.appLanguage?.let {
            if (it.isNotEmpty()) LanguageManager.currentLanguageCode = it
        }
    }

    // Handle back button to return to dashboard
    if (currentScreen != "dashboard") {
        BackHandler {
            currentScreen = "dashboard"
        }
    }

    Scaffold(
        topBar = {
            OfficeZenTopBar(
                offices = offices,
                selectedOfficeId = selectedOfficeId,
                onSelectOffice = { viewModel.selectOffice(it) },
                onAddOfficeClick = { showAddOfficeDialog = true },
                onLanguageClick = { showLanguageDialog = true },
                onLockClick = { showBossPinDialog = true },
                isUnlocked = isBossUnlocked
            )
        },
        bottomBar = {
            NavigationBar(
                windowInsets = WindowInsets.navigationBars
            ) {
                NavigationBarItem(
                    selected = currentScreen == "dashboard",
                    onClick = { currentScreen = "dashboard" },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                    label = { Text(tr("dashboard"), maxLines = 1) }
                )
                NavigationBarItem(
                    selected = currentScreen == "attendance",
                    onClick = { currentScreen = "attendance" },
                    icon = { Icon(Icons.Default.FactCheck, contentDescription = "Attendance") },
                    label = { Text(tr("attendance"), maxLines = 1) }
                )
                NavigationBarItem(
                    selected = currentScreen == "employees",
                    onClick = { currentScreen = "employees" },
                    icon = { Icon(Icons.Default.Badge, contentDescription = "Employees") },
                    label = { Text(tr("employees"), maxLines = 1) }
                )
                NavigationBarItem(
                    selected = currentScreen == "salary",
                    onClick = {
                        if (!isBossUnlocked) {
                            showBossPinDialog = true
                        } else {
                            currentScreen = "salary"
                        }
                    },
                    icon = { Icon(Icons.Default.Payments, contentDescription = "Salary") },
                    label = { Text(tr("salary"), maxLines = 1) }
                )
                NavigationBarItem(
                    selected = currentScreen == "settings",
                    onClick = { currentScreen = "settings" },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text(tr("settings"), maxLines = 1) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                "dashboard" -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigate = { screen ->
                        if ((screen == "salary" || screen == "boss_panel") && !isBossUnlocked) {
                            showBossPinDialog = true
                        } else {
                            currentScreen = screen
                        }
                    }
                )
                "attendance" -> AttendanceScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = "dashboard" }
                )
                "employees" -> EmployeesScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = "dashboard" }
                )
                "salary" -> SalaryScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = "dashboard" }
                )
                "tea_coffee" -> TeaCoffeeScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = "dashboard" }
                )
                "expenses" -> ExpensesScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = "dashboard" }
                )
                "documents" -> DocumentsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = "dashboard" }
                )
                "groups" -> GroupsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = "dashboard" }
                )
                "reports" -> ReportsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = "dashboard" }
                )
                "boss_panel" -> BossPanelScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = "dashboard" }
                )
                "tasks" -> TasksScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = "dashboard" }
                )
                "settings" -> SettingsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { currentScreen = "dashboard" }
                )
                else -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigate = { currentScreen = it }
                )
            }
        }
    }

    // Global Modals
    if (showLanguageDialog) {
        LanguageSelectionDialog(
            currentLanguageCode = LanguageManager.currentLanguageCode,
            onSelectLanguage = { code ->
                viewModel.setAppLanguage(code)
                showLanguageDialog = false
            },
            onDismiss = { showLanguageDialog = false }
        )
    }

    if (showBossPinDialog) {
        BossPinDialog(
            isOpen = true,
            onPinEntered = { pin ->
                viewModel.unlockBoss(pin)
            },
            onDismiss = { showBossPinDialog = false }
        )
    }

    if (showAddOfficeDialog) {
        var officeName by remember { mutableStateOf("") }
        var officeCode by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddOfficeDialog = false },
            title = { Text("Create New Office") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = officeName,
                        onValueChange = { officeName = it },
                        label = { Text("Office Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = officeCode,
                        onValueChange = { officeCode = it },
                        label = { Text("Office Code") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (officeName.isNotEmpty()) {
                            viewModel.addOffice(officeName, officeCode.ifEmpty { officeName.take(3).uppercase() })
                            showAddOfficeDialog = false
                        }
                    },
                    enabled = officeName.isNotEmpty()
                ) {
                    Text("Add Office")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddOfficeDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
