package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.i18n.LanguageManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OfficeZenViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    val repository = OfficeZenRepository(database.officeZenDao())

    // Selected Office filter (0 = All Offices combined, or specific office ID)
    private val _selectedOfficeId = MutableStateFlow<Long>(0L)
    val selectedOfficeId: StateFlow<Long> = _selectedOfficeId.asStateFlow()

    fun selectOffice(officeId: Long) {
        _selectedOfficeId.value = officeId
    }

    // Boss Profile & PIN State
    val bossProfile: StateFlow<BossProfileEntity?> = repository.bossProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _isBossUnlocked = MutableStateFlow(true) // Defaults to unlocked for smooth first demo
    val isBossUnlocked: StateFlow<Boolean> = _isBossUnlocked.asStateFlow()

    fun unlockBoss(pin: String): Boolean {
        val current = bossProfile.value?.pin ?: "123456"
        return if (pin == current) {
            _isBossUnlocked.value = true
            true
        } else {
            false
        }
    }

    fun lockBoss() {
        _isBossUnlocked.value = false
    }

    fun setAppLanguage(langCode: String) {
        LanguageManager.currentLanguageCode = langCode
        viewModelScope.launch {
            bossProfile.value?.let { current ->
                repository.updateBossProfile(current.copy(appLanguage = langCode))
            }
        }
    }

    // Offices & Departments
    val offices: StateFlow<List<OfficeEntity>> = repository.allOffices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val departments: StateFlow<List<DepartmentEntity>> = repository.allDepartments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addOffice(name: String, code: String) {
        viewModelScope.launch {
            val id = repository.addOffice(name, code)
            // Add default departments
            repository.addDepartment(id, "Accounts")
            repository.addDepartment(id, "Staff")
            repository.addDepartment(id, "Management")
            repository.logAction("Office Created", "Added new office $name ($code)")
        }
    }

    fun addDepartment(officeId: Long, name: String) {
        viewModelScope.launch {
            repository.addDepartment(officeId, name)
            repository.logAction("Department Created", "Added department $name to Office #$officeId")
        }
    }

    // Employees
    val allEmployees: StateFlow<List<EmployeeEntity>> = repository.allEmployees
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredEmployees: StateFlow<List<EmployeeEntity>> = combine(allEmployees, _selectedOfficeId) { list, officeId ->
        if (officeId == 0L) list else list.filter { it.officeId == officeId }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addEmployee(employee: EmployeeEntity) {
        viewModelScope.launch {
            repository.addEmployee(employee)
            repository.logAction("Employee Added", "Added ${employee.fullName} (${employee.employeeCode})")
        }
    }

    // Attendance
    val todayDate: String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    val currentMonth: String = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())

    val todayAttendance: StateFlow<List<AttendanceEntity>> = repository.getAttendanceByDate(todayDate)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun markAttendance(
        employee: EmployeeEntity,
        status: AttendanceStatus,
        selfieUri: String = "",
        remarks: String = ""
    ) {
        viewModelScope.launch {
            val existing = repository.getAttendanceRecord(employee.id, todayDate)
            val currentTime = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            if (existing != null) {
                // Update
                repository.updateAttendance(
                    existing.copy(
                        status = status,
                        selfieUri = if (selfieUri.isNotEmpty()) selfieUri else existing.selfieUri,
                        checkInTime = currentTime,
                        remarks = remarks
                    )
                )
            } else {
                repository.recordAttendance(
                    AttendanceEntity(
                        employeeId = employee.id,
                        officeId = employee.officeId,
                        departmentId = employee.departmentId,
                        date = todayDate,
                        checkInTime = currentTime,
                        status = status,
                        selfieUri = selfieUri,
                        remarks = remarks
                    )
                )
            }
            repository.logAction("Attendance Marked", "${employee.fullName} -> $status at $currentTime")
        }
    }

    // Tea & Coffee
    val recentTeaCoffee: StateFlow<List<TeaCoffeeEntity>> = repository.recentTeaCoffee
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun updateTeaCoffee(
        officeId: Long,
        teaCups: Int,
        teaRate: Double,
        coffeeCups: Int,
        coffeeRate: Double,
        note: String
    ) {
        viewModelScope.launch {
            val total = (teaCups * teaRate) + (coffeeCups * coffeeRate)
            val entity = TeaCoffeeEntity(
                officeId = officeId,
                date = todayDate,
                teaCups = teaCups,
                teaRate = teaRate,
                coffeeCups = coffeeCups,
                coffeeRate = coffeeRate,
                totalAmount = total,
                note = note
            )
            repository.saveTeaCoffee(entity)
            repository.logAction("Tea & Coffee Updated", "Office #$officeId: $teaCups Tea, $coffeeCups Coffee (₹$total)")
        }
    }

    // Expenses
    val allExpenses: StateFlow<List<ExpenseEntity>> = repository.allExpenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addExpense(officeId: Long, category: String, description: String, amount: Double, receiptUri: String = "") {
        viewModelScope.launch {
            repository.addExpense(
                ExpenseEntity(
                    officeId = officeId,
                    category = category,
                    description = description,
                    amount = amount,
                    date = todayDate,
                    receiptUri = receiptUri
                )
            )
            repository.logAction("Expense Added", "Office #$officeId: ₹$amount for $description")
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
            repository.logAction("Expense Deleted", "Removed ₹${expense.amount} (${expense.description})")
        }
    }

    // Documents
    val allDocuments: StateFlow<List<DocumentEntity>> = repository.allDocuments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addDocument(
        officeId: Long,
        deptId: Long,
        docName: String,
        personName: String,
        phone: String,
        expectedReturn: String
    ) {
        viewModelScope.launch {
            repository.addDocument(
                DocumentEntity(
                    officeId = officeId,
                    departmentId = deptId,
                    documentName = docName,
                    personName = personName,
                    phone = phone,
                    handoverDate = todayDate,
                    expectedReturnDate = expectedReturn,
                    status = DocumentStatus.PENDING
                )
            )
            repository.logAction("Document Handed Over", "$docName handed to $personName")
        }
    }

    fun returnDocument(doc: DocumentEntity) {
        viewModelScope.launch {
            repository.updateDocument(
                doc.copy(
                    status = DocumentStatus.RETURNED,
                    actualReturnDate = todayDate
                )
            )
            repository.logAction("Document Returned", "${doc.documentName} returned by ${doc.personName}")
        }
    }

    // Tasks
    val allTasks: StateFlow<List<TaskEntity>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun toggleTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.updateTask(task.copy(isCompleted = !task.isCompleted))
        }
    }

    fun addTask(officeId: Long, title: String, description: String, assignedEmpId: Long, dueDate: String) {
        viewModelScope.launch {
            repository.addTask(
                TaskEntity(
                    officeId = officeId,
                    title = title,
                    description = description,
                    assignedEmployeeId = assignedEmpId,
                    dueDate = dueDate,
                    isCompleted = false
                )
            )
        }
    }

    // Salary Calculation
    val currentMonthSalaryRecords: StateFlow<List<SalaryRecordEntity>> = repository.getSalaryRecordsByMonth(currentMonth)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun markSalaryPaid(record: SalaryRecordEntity) {
        viewModelScope.launch {
            repository.updateSalaryRecord(
                record.copy(
                    isPaid = true,
                    paidDate = todayDate
                )
            )
            repository.logAction("Salary Paid", "Record #${record.id} marked paid on $todayDate")
        }
    }

    fun computeAndSaveSalary(
        employee: EmployeeEntity,
        workingDays: Int = 26,
        presentDays: Double,
        advances: Double,
        otherDeductions: Double
    ) {
        viewModelScope.launch {
            val dailyRate = if (employee.salaryType == SalaryType.DAILY) {
                employee.baseRate
            } else {
                employee.baseRate / workingDays
            }
            val gross = dailyRate * presentDays
            val net = (gross - advances - otherDeductions).coerceAtLeast(0.0)

            val existing = repository.getSalaryRecordForEmployee(employee.id, currentMonth)
            if (existing != null) {
                repository.updateSalaryRecord(
                    existing.copy(
                        configuredWorkingDays = workingDays,
                        payableDays = presentDays,
                        dailyRate = dailyRate,
                        grossSalary = gross,
                        advanceDeductions = advances,
                        otherDeductions = otherDeductions,
                        netSalary = net
                    )
                )
            } else {
                repository.saveSalaryRecord(
                    SalaryRecordEntity(
                        employeeId = employee.id,
                        officeId = employee.officeId,
                        month = currentMonth,
                        configuredWorkingDays = workingDays,
                        payableDays = presentDays,
                        dailyRate = dailyRate,
                        grossSalary = gross,
                        advanceDeductions = advances,
                        otherDeductions = otherDeductions,
                        netSalary = net,
                        isPaid = false
                    )
                )
            }
            repository.logAction("Salary Computed", "${employee.fullName}: Net Payable ₹$net")
        }
    }

    // Audit logs
    val auditLogs: StateFlow<List<AuditLogEntity>> = repository.recentAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}
