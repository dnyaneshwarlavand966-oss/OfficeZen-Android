package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface OfficeZenDao {

    // Boss Profile
    @Query("SELECT * FROM boss_profile WHERE id = 1")
    fun getBossProfile(): Flow<BossProfileEntity?>

    @Query("SELECT * FROM boss_profile WHERE id = 1")
    suspend fun getBossProfileDirect(): BossProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateBossProfile(profile: BossProfileEntity)

    // Offices
    @Query("SELECT * FROM offices WHERE isArchived = 0 ORDER BY id ASC")
    fun getAllOffices(): Flow<List<OfficeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOffice(office: OfficeEntity): Long

    @Update
    suspend fun updateOffice(office: OfficeEntity)

    // Departments
    @Query("SELECT * FROM departments WHERE officeId = :officeId AND isArchived = 0")
    fun getDepartmentsByOffice(officeId: Long): Flow<List<DepartmentEntity>>

    @Query("SELECT * FROM departments WHERE isArchived = 0")
    fun getAllDepartments(): Flow<List<DepartmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDepartment(dept: DepartmentEntity): Long

    @Update
    suspend fun updateDepartment(dept: DepartmentEntity)

    // Employees
    @Query("SELECT * FROM employees WHERE isActive = 1 ORDER BY fullName ASC")
    fun getAllEmployees(): Flow<List<EmployeeEntity>>

    @Query("SELECT * FROM employees WHERE officeId = :officeId AND isActive = 1 ORDER BY fullName ASC")
    fun getEmployeesByOffice(officeId: Long): Flow<List<EmployeeEntity>>

    @Query("SELECT * FROM employees WHERE id = :id")
    suspend fun getEmployeeById(id: Long): EmployeeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmployee(employee: EmployeeEntity): Long

    @Update
    suspend fun updateEmployee(employee: EmployeeEntity)

    // Attendance
    @Query("SELECT * FROM attendance WHERE date = :date")
    fun getAttendanceByDate(date: String): Flow<List<AttendanceEntity>>

    @Query("SELECT * FROM attendance WHERE officeId = :officeId AND date = :date")
    fun getAttendanceByOfficeAndDate(officeId: Long, date: String): Flow<List<AttendanceEntity>>

    @Query("SELECT * FROM attendance WHERE employeeId = :employeeId AND date LIKE :monthPrefix || '%'")
    fun getAttendanceForEmployeeMonth(employeeId: Long, monthPrefix: String): Flow<List<AttendanceEntity>>

    @Query("SELECT * FROM attendance WHERE employeeId = :employeeId AND date = :date LIMIT 1")
    suspend fun getAttendanceRecord(employeeId: Long, date: String): AttendanceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendance(attendance: AttendanceEntity): Long

    @Update
    suspend fun updateAttendance(attendance: AttendanceEntity)

    // Tea and Coffee
    @Query("SELECT * FROM tea_coffee WHERE date = :date")
    fun getTeaCoffeeByDate(date: String): Flow<List<TeaCoffeeEntity>>

    @Query("SELECT * FROM tea_coffee WHERE officeId = :officeId AND date = :date LIMIT 1")
    suspend fun getTeaCoffeeForOfficeAndDate(officeId: Long, date: String): TeaCoffeeEntity?

    @Query("SELECT * FROM tea_coffee ORDER BY date DESC LIMIT 30")
    fun getRecentTeaCoffee(): Flow<List<TeaCoffeeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateTeaCoffee(teaCoffee: TeaCoffeeEntity): Long

    // Expenses
    @Query("SELECT * FROM expenses ORDER BY date DESC")
    fun getAllExpenses(): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE officeId = :officeId ORDER BY date DESC")
    fun getExpensesByOffice(officeId: Long): Flow<List<ExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity): Long

    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity)

    // Documents
    @Query("SELECT * FROM documents ORDER BY handoverDate DESC")
    fun getAllDocuments(): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM documents WHERE officeId = :officeId ORDER BY handoverDate DESC")
    fun getDocumentsByOffice(officeId: Long): Flow<List<DocumentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(doc: DocumentEntity): Long

    @Update
    suspend fun updateDocument(doc: DocumentEntity)

    // Salary Records
    @Query("SELECT * FROM salary_records WHERE month = :month")
    fun getSalaryRecordsByMonth(month: String): Flow<List<SalaryRecordEntity>>

    @Query("SELECT * FROM salary_records WHERE employeeId = :employeeId AND month = :month LIMIT 1")
    suspend fun getSalaryRecordForEmployee(employeeId: Long, month: String): SalaryRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSalaryRecord(record: SalaryRecordEntity): Long

    @Update
    suspend fun updateSalaryRecord(record: SalaryRecordEntity)

    // Leaves
    @Query("SELECT * FROM leaves ORDER BY startDate DESC")
    fun getAllLeaves(): Flow<List<LeaveEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeave(leave: LeaveEntity): Long

    @Update
    suspend fun updateLeave(leave: LeaveEntity)

    // Tasks
    @Query("SELECT * FROM tasks ORDER BY isCompleted ASC, dueDate ASC")
    fun getAllTasks(): Flow<List<TaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity): Long

    @Update
    suspend fun updateTask(task: TaskEntity)

    // Audit logs
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity): Long
}
