package com.example.data.local

import kotlinx.coroutines.flow.Flow

class OfficeZenRepository(private val dao: OfficeZenDao) {

    // Boss Profile
    val bossProfile: Flow<BossProfileEntity?> = dao.getBossProfile()
    suspend fun getBossProfileDirect(): BossProfileEntity? = dao.getBossProfileDirect()
    suspend fun updateBossProfile(profile: BossProfileEntity) = dao.insertOrUpdateBossProfile(profile)

    // Offices & Departments
    val allOffices: Flow<List<OfficeEntity>> = dao.getAllOffices()
    suspend fun addOffice(name: String, code: String): Long = dao.insertOffice(OfficeEntity(name = name, code = code))
    suspend fun updateOffice(office: OfficeEntity) = dao.updateOffice(office)

    val allDepartments: Flow<List<DepartmentEntity>> = dao.getAllDepartments()
    fun getDepartmentsByOffice(officeId: Long): Flow<List<DepartmentEntity>> = dao.getDepartmentsByOffice(officeId)
    suspend fun addDepartment(officeId: Long, name: String): Long = dao.insertDepartment(DepartmentEntity(officeId = officeId, name = name))
    suspend fun updateDepartment(dept: DepartmentEntity) = dao.updateDepartment(dept)

    // Employees
    val allEmployees: Flow<List<EmployeeEntity>> = dao.getAllEmployees()
    fun getEmployeesByOffice(officeId: Long): Flow<List<EmployeeEntity>> = dao.getEmployeesByOffice(officeId)
    suspend fun getEmployeeById(id: Long): EmployeeEntity? = dao.getEmployeeById(id)
    suspend fun addEmployee(employee: EmployeeEntity): Long = dao.insertEmployee(employee)
    suspend fun updateEmployee(employee: EmployeeEntity) = dao.updateEmployee(employee)

    // Attendance
    fun getAttendanceByDate(date: String): Flow<List<AttendanceEntity>> = dao.getAttendanceByDate(date)
    fun getAttendanceByOfficeAndDate(officeId: Long, date: String): Flow<List<AttendanceEntity>> = dao.getAttendanceByOfficeAndDate(officeId, date)
    suspend fun recordAttendance(attendance: AttendanceEntity): Long = dao.insertAttendance(attendance)
    suspend fun getAttendanceRecord(employeeId: Long, date: String): AttendanceEntity? = dao.getAttendanceRecord(employeeId, date)
    suspend fun updateAttendance(attendance: AttendanceEntity) = dao.updateAttendance(attendance)

    // Tea and Coffee
    fun getTeaCoffeeByDate(date: String): Flow<List<TeaCoffeeEntity>> = dao.getTeaCoffeeByDate(date)
    suspend fun getTeaCoffeeForOfficeAndDate(officeId: Long, date: String): TeaCoffeeEntity? = dao.getTeaCoffeeForOfficeAndDate(officeId, date)
    suspend fun saveTeaCoffee(teaCoffee: TeaCoffeeEntity): Long = dao.insertOrUpdateTeaCoffee(teaCoffee)
    val recentTeaCoffee: Flow<List<TeaCoffeeEntity>> = dao.getRecentTeaCoffee()

    // Expenses
    val allExpenses: Flow<List<ExpenseEntity>> = dao.getAllExpenses()
    fun getExpensesByOffice(officeId: Long): Flow<List<ExpenseEntity>> = dao.getExpensesByOffice(officeId)
    suspend fun addExpense(expense: ExpenseEntity): Long = dao.insertExpense(expense)
    suspend fun deleteExpense(expense: ExpenseEntity) = dao.deleteExpense(expense)

    // Documents
    val allDocuments: Flow<List<DocumentEntity>> = dao.getAllDocuments()
    fun getDocumentsByOffice(officeId: Long): Flow<List<DocumentEntity>> = dao.getDocumentsByOffice(officeId)
    suspend fun addDocument(doc: DocumentEntity): Long = dao.insertDocument(doc)
    suspend fun updateDocument(doc: DocumentEntity) = dao.updateDocument(doc)

    // Salary Records
    fun getSalaryRecordsByMonth(month: String): Flow<List<SalaryRecordEntity>> = dao.getSalaryRecordsByMonth(month)
    suspend fun getSalaryRecordForEmployee(employeeId: Long, month: String): SalaryRecordEntity? = dao.getSalaryRecordForEmployee(employeeId, month)
    suspend fun saveSalaryRecord(record: SalaryRecordEntity): Long = dao.insertSalaryRecord(record)
    suspend fun updateSalaryRecord(record: SalaryRecordEntity) = dao.updateSalaryRecord(record)

    // Leaves
    val allLeaves: Flow<List<LeaveEntity>> = dao.getAllLeaves()
    suspend fun addLeave(leave: LeaveEntity): Long = dao.insertLeave(leave)
    suspend fun updateLeave(leave: LeaveEntity) = dao.updateLeave(leave)

    // Tasks
    val allTasks: Flow<List<TaskEntity>> = dao.getAllTasks()
    suspend fun addTask(task: TaskEntity): Long = dao.insertTask(task)
    suspend fun updateTask(task: TaskEntity) = dao.updateTask(task)

    // Audit logs
    val recentAuditLogs: Flow<List<AuditLogEntity>> = dao.getRecentAuditLogs()
    suspend fun logAction(action: String, details: String) = dao.insertAuditLog(AuditLogEntity(action = action, details = details))
}
