package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Database(
    entities = [
        OfficeEntity::class,
        DepartmentEntity::class,
        EmployeeEntity::class,
        AttendanceEntity::class,
        TeaCoffeeEntity::class,
        ExpenseEntity::class,
        DocumentEntity::class,
        SalaryRecordEntity::class,
        LeaveEntity::class,
        TaskEntity::class,
        BossProfileEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun officeZenDao(): OfficeZenDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "officezen_database"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database.officeZenDao())
                }
            }
        }

        private suspend fun populateInitialData(dao: OfficeZenDao) {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val currentMonth = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())

            // 1. Initial Boss Profile
            dao.insertOrUpdateBossProfile(
                BossProfileEntity(
                    id = 1,
                    bossName = "Boss Executive",
                    pin = "123456",
                    isSetupCompleted = true,
                    appLanguage = "en",
                    requirePinOnResume = false
                )
            )

            // 2. SJ Office & DIT Office
            val sjId = dao.insertOffice(OfficeEntity(name = "SJ Office", code = "SJ"))
            val ditId = dao.insertOffice(OfficeEntity(name = "DIT Office", code = "DIT"))

            // 3. Departments
            val sjAccounts = dao.insertDepartment(DepartmentEntity(officeId = sjId, name = "Accounts"))
            val sjStaff = dao.insertDepartment(DepartmentEntity(officeId = sjId, name = "Staff"))
            val sjMgmt = dao.insertDepartment(DepartmentEntity(officeId = sjId, name = "Management"))

            val ditAccounts = dao.insertDepartment(DepartmentEntity(officeId = ditId, name = "Accounts"))
            val ditStaff = dao.insertDepartment(DepartmentEntity(officeId = ditId, name = "Staff"))
            val ditMgmt = dao.insertDepartment(DepartmentEntity(officeId = ditId, name = "Management"))

            // 4. Employees for SJ Office
            val emp1 = dao.insertEmployee(
                EmployeeEntity(
                    officeId = sjId,
                    departmentId = sjAccounts,
                    employeeCode = "SJ-101",
                    fullName = "Rahul Sharma",
                    phone = "9823012345",
                    designation = "Senior Accountant",
                    salaryType = SalaryType.MONTHLY,
                    baseRate = 32000.0,
                    joiningDate = "2024-01-15"
                )
            )
            val emp2 = dao.insertEmployee(
                EmployeeEntity(
                    officeId = sjId,
                    departmentId = sjStaff,
                    employeeCode = "SJ-102",
                    fullName = "Pooja Patil",
                    phone = "9823054321",
                    designation = "Executive Coordinator",
                    salaryType = SalaryType.MONTHLY,
                    baseRate = 28000.0,
                    joiningDate = "2024-03-01"
                )
            )
            val emp3 = dao.insertEmployee(
                EmployeeEntity(
                    officeId = sjId,
                    departmentId = sjMgmt,
                    employeeCode = "SJ-103",
                    fullName = "Sunil Jadhav",
                    phone = "9823098765",
                    designation = "Operations Specialist",
                    salaryType = SalaryType.DAILY,
                    baseRate = 950.0,
                    joiningDate = "2024-05-10"
                )
            )

            // 5. Employees for DIT Office
            val emp4 = dao.insertEmployee(
                EmployeeEntity(
                    officeId = ditId,
                    departmentId = ditAccounts,
                    employeeCode = "DIT-201",
                    fullName = "Aniket Joshi",
                    phone = "9422011223",
                    designation = "Billing Associate",
                    salaryType = SalaryType.MONTHLY,
                    baseRate = 26000.0,
                    joiningDate = "2024-02-12"
                )
            )
            val emp5 = dao.insertEmployee(
                EmployeeEntity(
                    officeId = ditId,
                    departmentId = ditStaff,
                    employeeCode = "DIT-202",
                    fullName = "Sneha Kulkarni",
                    phone = "9422077889",
                    designation = "Tech Support Lead",
                    salaryType = SalaryType.MONTHLY,
                    baseRate = 30000.0,
                    joiningDate = "2024-04-05"
                )
            )

            // 6. Pre-populated Today's Attendance
            dao.insertAttendance(
                AttendanceEntity(
                    employeeId = emp1,
                    officeId = sjId,
                    departmentId = sjAccounts,
                    date = today,
                    checkInTime = "09:30 AM",
                    status = AttendanceStatus.PRESENT,
                    selfieUri = "",
                    remarks = "On time check-in"
                )
            )
            dao.insertAttendance(
                AttendanceEntity(
                    employeeId = emp2,
                    officeId = sjId,
                    departmentId = sjStaff,
                    date = today,
                    checkInTime = "09:42 AM",
                    status = AttendanceStatus.PRESENT,
                    selfieUri = "",
                    remarks = "Selfie verified"
                )
            )

            // 7. Tea & Coffee Records for today
            dao.insertOrUpdateTeaCoffee(
                TeaCoffeeEntity(
                    officeId = sjId,
                    date = today,
                    teaCups = 8,
                    teaRate = 12.0,
                    coffeeCups = 3,
                    coffeeRate = 20.0,
                    totalAmount = (8 * 12.0) + (3 * 20.0),
                    note = "Morning & afternoon rounds"
                )
            )
            dao.insertOrUpdateTeaCoffee(
                TeaCoffeeEntity(
                    officeId = ditId,
                    date = today,
                    teaCups = 6,
                    teaRate = 12.0,
                    coffeeCups = 4,
                    coffeeRate = 20.0,
                    totalAmount = (6 * 12.0) + (4 * 20.0),
                    note = "Client visitor hospitality"
                )
            )

            // 8. Sample Expenses
            dao.insertExpense(
                ExpenseEntity(
                    officeId = sjId,
                    category = "Stationary",
                    description = "Printer Cartridge & A4 reams",
                    amount = 1450.0,
                    date = today
                )
            )
            dao.insertExpense(
                ExpenseEntity(
                    officeId = ditId,
                    category = "Internet",
                    description = "Fiber Broadband monthly renewal",
                    amount = 999.0,
                    date = today
                )
            )

            // 9. Sample Document Handover Record
            dao.insertDocument(
                DocumentEntity(
                    officeId = sjId,
                    departmentId = sjAccounts,
                    documentName = "GST Registration Deed & Audit File",
                    personName = "CA Mahesh Deshmukh",
                    phone = "9822199887",
                    handoverDate = today,
                    expectedReturnDate = "2026-11-15",
                    status = DocumentStatus.PENDING
                )
            )

            // 10. Sample Tasks
            dao.insertTask(
                TaskEntity(
                    officeId = sjId,
                    title = "Audit Q3 Expense Vouchers",
                    description = "Cross-verify tea, travel, and vendor bills with account books",
                    assignedEmployeeId = emp1,
                    dueDate = "2026-11-10",
                    isCompleted = false
                )
            )
            dao.insertTask(
                TaskEntity(
                    officeId = ditId,
                    title = "Monthly Server & Backup Health Check",
                    description = "Export encrypted database archives to secure local disk",
                    assignedEmployeeId = emp5,
                    dueDate = "2026-11-08",
                    isCompleted = true
                )
            )

            // 11. Initial Audit Log
            dao.insertAuditLog(
                AuditLogEntity(
                    action = "System Initialized",
                    details = "OfficeZen provisioned SJ Office and DIT Office with default departments and sample accounts."
                )
            )
        }
    }
}
