package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "offices")
data class OfficeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val code: String,
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "departments")
data class DepartmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val officeId: Long,
    val name: String,
    val isArchived: Boolean = false
)

enum class SalaryType {
    DAILY,
    MONTHLY
}

@Entity(tableName = "employees")
data class EmployeeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val officeId: Long,
    val departmentId: Long,
    val employeeCode: String,
    val fullName: String,
    val phone: String,
    val designation: String,
    val salaryType: SalaryType = SalaryType.MONTHLY,
    val baseRate: Double = 25000.0,
    val joiningDate: String = "",
    val photoUri: String = "",
    val isActive: Boolean = true
)

enum class AttendanceStatus {
    PRESENT,
    ABSENT,
    LEAVE,
    HALF_DAY
}

@Entity(tableName = "attendance")
data class AttendanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val officeId: Long,
    val departmentId: Long,
    val date: String, // YYYY-MM-DD
    val checkInTime: String, // HH:mm:ss
    val status: AttendanceStatus,
    val selfieUri: String = "",
    val isApprovedByBoss: Boolean = true,
    val remarks: String = ""
)

@Entity(tableName = "tea_coffee")
data class TeaCoffeeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val officeId: Long,
    val date: String, // YYYY-MM-DD
    val teaCups: Int = 0,
    val teaRate: Double = 12.0,
    val coffeeCups: Int = 0,
    val coffeeRate: Double = 20.0,
    val totalAmount: Double = 0.0,
    val note: String = ""
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val officeId: Long,
    val category: String, // Stationary, Travel, Electricity, Internet, Maintenance, Food, Misc
    val description: String,
    val amount: Double,
    val date: String, // YYYY-MM-DD
    val receiptUri: String = ""
)

enum class DocumentStatus {
    PENDING,
    RETURNED
}

@Entity(tableName = "documents")
data class DocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val officeId: Long,
    val departmentId: Long,
    val documentName: String,
    val personName: String,
    val phone: String,
    val handoverDate: String, // YYYY-MM-DD
    val expectedReturnDate: String, // YYYY-MM-DD
    val actualReturnDate: String = "",
    val status: DocumentStatus = DocumentStatus.PENDING,
    val photoUri: String = ""
)

@Entity(tableName = "salary_records")
data class SalaryRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val officeId: Long,
    val month: String, // YYYY-MM
    val configuredWorkingDays: Int = 26,
    val payableDays: Double = 26.0,
    val dailyRate: Double = 0.0,
    val grossSalary: Double = 0.0,
    val advanceDeductions: Double = 0.0,
    val otherDeductions: Double = 0.0,
    val netSalary: Double = 0.0,
    val isPaid: Boolean = false,
    val paidDate: String = "",
    val isFinalized: Boolean = false
)

enum class LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}

@Entity(tableName = "leaves")
data class LeaveEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val officeId: Long,
    val startDate: String,
    val endDate: String,
    val reason: String,
    val status: LeaveStatus = LeaveStatus.PENDING
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val officeId: Long,
    val title: String,
    val description: String = "",
    val assignedEmployeeId: Long = 0L,
    val dueDate: String = "",
    val isCompleted: Boolean = false
)

@Entity(tableName = "boss_profile")
data class BossProfileEntity(
    @PrimaryKey val id: Int = 1,
    val bossName: String = "Ashwini Vakale",
    val pin: String = "123456",
    val isSetupCompleted: Boolean = true,
    val appLanguage: String = "en",
    val requirePinOnResume: Boolean = false
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val action: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)
