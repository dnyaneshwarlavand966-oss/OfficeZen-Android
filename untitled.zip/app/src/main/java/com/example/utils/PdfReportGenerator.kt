package com.example.utils

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.local.AttendanceEntity
import com.example.data.local.EmployeeEntity
import com.example.data.local.ExpenseEntity
import com.example.data.local.TeaCoffeeEntity
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfReportGenerator {

    fun generateOfficeZenSummaryPdf(
        context: Context,
        officeName: String,
        dateOrMonth: String,
        employees: List<EmployeeEntity>,
        attendanceList: List<AttendanceEntity>,
        teaCoffeeList: List<TeaCoffeeEntity>,
        expensesList: List<ExpenseEntity>
    ): File? {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // Standard A4 (points)
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint().apply {
            color = Color.parseColor("#1E3A8A")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val subTitlePaint = Paint().apply {
            color = Color.parseColor("#475569")
            textSize = 12f
            isAntiAlias = true
        }

        val headerPaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 14f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 11f
            isAntiAlias = true
        }

        val linePaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            strokeWidth = 1f
        }

        var y = 45f

        // Document Header
        canvas.drawText("OfficeZen – Master Office Report", 40f, y, titlePaint)
        y += 20f
        val timestamp = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
        canvas.drawText("Office: $officeName  |  Generated on: $timestamp", 40f, y, subTitlePaint)
        y += 15f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 25f

        // Section 1: Attendance Summary
        canvas.drawText("1. Attendance Record ($dateOrMonth)", 40f, y, headerPaint)
        y += 18f

        val presentCount = attendanceList.count { it.status.name == "PRESENT" }
        val absentCount = attendanceList.count { it.status.name == "ABSENT" }
        val leaveCount = attendanceList.count { it.status.name == "LEAVE" }
        canvas.drawText("Summary: Present: $presentCount | Absent: $absentCount | Leave: $leaveCount | Total Active: ${employees.size}", 40f, y, textPaint)
        y += 18f

        // Attendance Table
        canvas.drawText("Code", 40f, y, subTitlePaint)
        canvas.drawText("Employee Name", 100f, y, subTitlePaint)
        canvas.drawText("Status", 300f, y, subTitlePaint)
        canvas.drawText("Time / Remarks", 420f, y, subTitlePaint)
        y += 10f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 16f

        employees.take(8).forEach { emp ->
            val att = attendanceList.find { it.employeeId == emp.id }
            val statusText = att?.status?.name ?: "NOT MARKED"
            val timeText = att?.checkInTime ?: "--"

            canvas.drawText(emp.employeeCode, 40f, y, textPaint)
            canvas.drawText(emp.fullName, 100f, y, textPaint)
            canvas.drawText(statusText, 300f, y, textPaint)
            canvas.drawText(timeText, 420f, y, textPaint)
            y += 16f
        }

        y += 15f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 25f

        // Section 2: Tea & Coffee Log
        canvas.drawText("2. Tea & Coffee Records", 40f, y, headerPaint)
        y += 18f
        var totalTeaCups = 0
        var totalCoffeeCups = 0
        var totalBeverageAmt = 0.0

        teaCoffeeList.forEach {
            totalTeaCups += it.teaCups
            totalCoffeeCups += it.coffeeCups
            totalBeverageAmt += it.totalAmount
        }

        canvas.drawText("Total Cups: Tea $totalTeaCups cups | Coffee $totalCoffeeCups cups | Total Bill: ₹$totalBeverageAmt", 40f, y, textPaint)
        y += 25f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 25f

        // Section 3: Office Expenses
        canvas.drawText("3. Office Expenses", 40f, y, headerPaint)
        y += 18f
        val totalExp = expensesList.sumOf { it.amount }
        canvas.drawText("Total Recorded Expenses: ₹$totalExp across ${expensesList.size} items", 40f, y, textPaint)
        y += 18f

        expensesList.take(5).forEach { exp ->
            canvas.drawText("• [${exp.category}] ${exp.description} : ₹${exp.amount} (${exp.date})", 50f, y, textPaint)
            y += 16f
        }

        // Footer
        val footerPaint = Paint().apply {
            color = Color.parseColor("#94A3B8")
            textSize = 9f
            isAntiAlias = true
        }
        canvas.drawText("OfficeZen Native Android Management System • 100% Offline Secured", 40f, 810f, footerPaint)

        pdfDocument.finishPage(page)

        return try {
            val reportsDir = File(context.filesDir, "reports")
            if (!reportsDir.exists()) reportsDir.mkdirs()
            val file = File(reportsDir, "OfficeZen_Report_${System.currentTimeMillis()}.pdf")
            val outputStream = FileOutputStream(file)
            pdfDocument.writeTo(outputStream)
            outputStream.close()
            pdfDocument.close()
            file
        } catch (e: Exception) {
            e.printStackTrace()
            pdfDocument.close()
            null
        }
    }

    fun sharePdf(context: Context, pdfFile: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            pdfFile
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share OfficeZen PDF Report"))
    }
}
