package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.EmployeeEntity
import com.example.data.local.SalaryRecordEntity
import com.example.data.local.SalaryType
import com.example.i18n.tr
import com.example.ui.theme.*
import com.example.viewmodel.OfficeZenViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalaryScreen(
    viewModel: OfficeZenViewModel,
    onNavigateBack: () -> Unit
) {
    val employees by viewModel.filteredEmployees.collectAsStateWithLifecycle()
    val salaryRecords by viewModel.currentMonthSalaryRecords.collectAsStateWithLifecycle()
    val isBossUnlocked by viewModel.isBossUnlocked.collectAsStateWithLifecycle()

    var selectedEmployeeForCalc by remember { mutableStateOf<EmployeeEntity?>(null) }
    var presentDaysText by remember { mutableStateOf("26") }
    var workingDaysText by remember { mutableStateOf("26") }
    var advancesText by remember { mutableStateOf("0") }
    var otherDeductionsText by remember { mutableStateOf("0") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tr("salary"), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // Month Header
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Slate100),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Payroll: ${viewModel.currentMonth}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        )
                        Text(
                            text = "Daily & Monthly Automatic Calculations",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate600
                        )
                    }
                    val totalDisbursed = salaryRecords.filter { it.isPaid }.sumOf { it.netSalary }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Paid: ₹$totalDisbursed", fontWeight = FontWeight.Bold, color = EmeraldPresent)
                        Text("${salaryRecords.count { it.isPaid }} Paid", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(employees) { emp ->
                    val record = salaryRecords.find { it.employeeId == emp.id }

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = emp.fullName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${emp.designation} (${emp.employeeCode})",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (record?.isPaid == true) EmeraldContainer else RoseContainer
                                ) {
                                    Text(
                                        text = if (record?.isPaid == true) "PAID" else "PENDING",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (record?.isPaid == true) EmeraldPresent else RoseAbsent,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Base Rate: ₹${emp.baseRate.toInt()} / ${if (emp.salaryType == SalaryType.DAILY) "day" else "month"}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    val net = record?.netSalary ?: emp.baseRate
                                    Text(
                                        text = "Net Payable: ₹${net.toInt()}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                Row {
                                    Button(
                                        onClick = {
                                            selectedEmployeeForCalc = emp
                                            presentDaysText = (record?.payableDays ?: 26.0).toInt().toString()
                                            workingDaysText = (record?.configuredWorkingDays ?: 26).toString()
                                            advancesText = (record?.advanceDeductions ?: 0.0).toInt().toString()
                                            otherDeductionsText = (record?.otherDeductions ?: 0.0).toInt().toString()
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text("Calculate", color = MaterialTheme.colorScheme.onSecondaryContainer, style = MaterialTheme.typography.labelSmall)
                                    }

                                    if (record != null && !record.isPaid) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Button(
                                            onClick = { viewModel.markSalaryPaid(record) },
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPresent),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text("Mark Paid", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Salary Calculator Dialog
    if (selectedEmployeeForCalc != null) {
        val emp = selectedEmployeeForCalc!!
        AlertDialog(
            onDismissRequest = { selectedEmployeeForCalc = null },
            title = { Text("Calculate Salary – ${emp.fullName}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Configured Base: ₹${emp.baseRate} (${emp.salaryType.name})", style = MaterialTheme.typography.bodySmall)

                    OutlinedTextField(
                        value = workingDaysText,
                        onValueChange = { workingDaysText = it },
                        label = { Text("Month Working Days") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = presentDaysText,
                        onValueChange = { presentDaysText = it },
                        label = { Text("Payable Days (Present + Paid Leaves)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = advancesText,
                        onValueChange = { advancesText = it },
                        label = { Text("Advance Deductions (₹)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = otherDeductionsText,
                        onValueChange = { otherDeductionsText = it },
                        label = { Text("Other Deductions (₹)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val workingDays = workingDaysText.toIntOrNull() ?: 26
                        val presentDays = presentDaysText.toDoubleOrNull() ?: 26.0
                        val advances = advancesText.toDoubleOrNull() ?: 0.0
                        val deductions = otherDeductionsText.toDoubleOrNull() ?: 0.0

                        viewModel.computeAndSaveSalary(
                            employee = emp,
                            workingDays = workingDays,
                            presentDays = presentDays,
                            advances = advances,
                            otherDeductions = deductions
                        )
                        selectedEmployeeForCalc = null
                    }
                ) {
                    Text("Save Calculation")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedEmployeeForCalc = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
