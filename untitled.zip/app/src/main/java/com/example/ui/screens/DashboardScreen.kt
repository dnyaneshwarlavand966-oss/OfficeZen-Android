package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.i18n.tr
import com.example.ui.components.MetricStatCard
import com.example.ui.theme.*
import com.example.utils.PdfReportGenerator
import com.example.viewmodel.OfficeZenViewModel

@Composable
fun DashboardScreen(
    viewModel: OfficeZenViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val offices by viewModel.offices.collectAsStateWithLifecycle()
    val selectedOfficeId by viewModel.selectedOfficeId.collectAsStateWithLifecycle()
    val employees by viewModel.filteredEmployees.collectAsStateWithLifecycle()
    val todayAttendance by viewModel.todayAttendance.collectAsStateWithLifecycle()
    val teaCoffeeList by viewModel.recentTeaCoffee.collectAsStateWithLifecycle()
    val expenses by viewModel.allExpenses.collectAsStateWithLifecycle()
    val tasks by viewModel.allTasks.collectAsStateWithLifecycle()

    val currentOffice = offices.find { it.id == selectedOfficeId }
    val officeTitle = currentOffice?.name ?: tr("all_offices")

    val presentCount = todayAttendance.count { it.status.name == "PRESENT" }
    val absentCount = todayAttendance.count { it.status.name == "ABSENT" }
    val leaveCount = todayAttendance.count { it.status.name == "LEAVE" }

    val todayTeaCoffee = teaCoffeeList.find {
        it.date == viewModel.todayDate && (selectedOfficeId == 0L || it.officeId == selectedOfficeId)
    }
    val todayBeverageTotal = todayTeaCoffee?.totalAmount ?: 0.0

    val totalExpensesMonth = expenses.filter {
        it.date.startsWith(viewModel.currentMonth) && (selectedOfficeId == 0L || it.officeId == selectedOfficeId)
    }.sumOf { it.amount }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp)
    ) {
        // Welcome & Office Banner
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Executive Control",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = officeTitle,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${employees.size} Active Staff • 100% Offline Secured",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                    Button(
                        onClick = {
                            val file = PdfReportGenerator.generateOfficeZenSummaryPdf(
                                context = context,
                                officeName = officeTitle,
                                dateOrMonth = viewModel.todayDate,
                                employees = employees,
                                attendanceList = todayAttendance,
                                teaCoffeeList = teaCoffeeList,
                                expensesList = expenses
                            )
                            if (file != null) {
                                PdfReportGenerator.sharePdf(context, file)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("PDF", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        // Live Metric Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricStatCard(
                    title = "Today Present",
                    value = "$presentCount",
                    icon = Icons.Default.CheckCircle,
                    containerColor = EmeraldContainer,
                    contentColor = EmeraldPresent,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("attendance") }
                )
                MetricStatCard(
                    title = "Absent / Leave",
                    value = "${absentCount + leaveCount}",
                    icon = Icons.Default.Cancel,
                    containerColor = RoseContainer,
                    contentColor = RoseAbsent,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("attendance") }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricStatCard(
                    title = "Tea & Coffee Today",
                    value = "₹$todayBeverageTotal",
                    icon = Icons.Default.LocalCafe,
                    containerColor = AmberGoldContainer,
                    contentColor = AmberGold,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("tea_coffee") }
                )
                MetricStatCard(
                    title = "Expenses (Month)",
                    value = "₹$totalExpensesMonth",
                    icon = Icons.Default.ReceiptLong,
                    containerColor = Slate100,
                    contentColor = Slate800,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("expenses") }
                )
            }
        }

        // Quick Functional Modules Grid
        item {
            Text(
                text = "Operational Modules",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickModuleButton(
                    title = tr("attendance"),
                    icon = Icons.Default.FactCheck,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("attendance") }
                )
                QuickModuleButton(
                    title = tr("employees"),
                    icon = Icons.Default.Badge,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("employees") }
                )
                QuickModuleButton(
                    title = tr("salary"),
                    icon = Icons.Default.Payments,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("salary") }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickModuleButton(
                    title = tr("tea_coffee"),
                    icon = Icons.Default.LocalCafe,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("tea_coffee") }
                )
                QuickModuleButton(
                    title = tr("documents"),
                    icon = Icons.Default.FolderShared,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("documents") }
                )
                QuickModuleButton(
                    title = tr("expenses"),
                    icon = Icons.Default.Receipt,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("expenses") }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickModuleButton(
                    title = tr("groups"),
                    icon = Icons.Default.CorporateFare,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("groups") }
                )
                QuickModuleButton(
                    title = tr("reports"),
                    icon = Icons.Default.Analytics,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("reports") }
                )
                QuickModuleButton(
                    title = tr("boss_panel"),
                    icon = Icons.Default.AdminPanelSettings,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("boss_panel") }
                )
            }
        }

        // Active Tasks Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Key Office Tasks",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = { onNavigate("tasks") }) {
                    Text("View All")
                }
            }
        }

        items(tasks.take(3)) { task ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = task.isCompleted,
                        onCheckedChange = { viewModel.toggleTask(task) }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = task.title,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = if (task.isCompleted) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface
                        )
                        if (task.description.isNotEmpty()) {
                            Text(
                                text = task.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                    if (task.dueDate.isNotEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = task.dueDate,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickModuleButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        shadowElevation = 1.dp,
        onClick = onClick,
        modifier = modifier.height(84.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
        }
    }
}
