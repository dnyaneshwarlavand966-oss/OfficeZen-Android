package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.AttendanceEntity
import com.example.data.local.AttendanceStatus
import com.example.data.local.EmployeeEntity
import com.example.i18n.tr
import com.example.ui.theme.*
import com.example.viewmodel.OfficeZenViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(
    viewModel: OfficeZenViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val employees by viewModel.filteredEmployees.collectAsStateWithLifecycle()
    val todayAttendance by viewModel.todayAttendance.collectAsStateWithLifecycle()
    val offices by viewModel.offices.collectAsStateWithLifecycle()
    val departments by viewModel.departments.collectAsStateWithLifecycle()

    var selectedEmployeeForSelfie by remember { mutableStateOf<EmployeeEntity?>(null) }
    var selectedStatus by remember { mutableStateOf(AttendanceStatus.PRESENT) }
    var remarksText by remember { mutableStateOf("") }
    var showCameraModal by remember { mutableStateOf(false) }
    var selfieCaptured by remember { mutableStateOf(false) }

    // Camera permission launcher
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
        if (isGranted) {
            showCameraModal = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tr("attendance"), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        // 5 PM attendance reminder preview
                    }) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = "Reminder Alert", tint = AmberGold)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // Header summary
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Slate100),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Daily Attendance Log",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        )
                        Text(
                            text = "Date: ${viewModel.todayDate}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate600
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = EmeraldContainer
                    ) {
                        Text(
                            text = "${todayAttendance.size} / ${employees.size} Recorded",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPresent,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Text(
                text = "Select Employee to Mark Attendance & Selfie",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            // Employee list for attendance
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(employees) { emp ->
                    val existingAtt = todayAttendance.find { it.employeeId == emp.id }
                    val deptName = departments.find { it.id == emp.departmentId }?.name ?: "General"
                    val officeName = offices.find { it.id == emp.officeId }?.name ?: ""

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (existingAtt != null) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedEmployeeForSelfie = emp
                                selectedStatus = existingAtt?.status ?: AttendanceStatus.PRESENT
                                remarksText = existingAtt?.remarks ?: ""
                                selfieCaptured = existingAtt?.selfieUri?.isNotEmpty() == true
                                if (!hasCameraPermission) {
                                    permissionLauncher.launch(Manifest.permission.CAMERA)
                                } else {
                                    showCameraModal = true
                                }
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Avatar
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = emp.fullName.take(2).uppercase(),
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = emp.fullName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${emp.employeeCode} • $deptName ($officeName)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                            // Status Pill
                            if (existingAtt != null) {
                                val pillBg = when (existingAtt.status) {
                                    AttendanceStatus.PRESENT -> EmeraldContainer
                                    AttendanceStatus.ABSENT -> RoseContainer
                                    AttendanceStatus.LEAVE -> VioletContainer
                                    AttendanceStatus.HALF_DAY -> AmberGoldContainer
                                }
                                val pillColor = when (existingAtt.status) {
                                    AttendanceStatus.PRESENT -> EmeraldPresent
                                    AttendanceStatus.ABSENT -> RoseAbsent
                                    AttendanceStatus.LEAVE -> VioletLeave
                                    AttendanceStatus.HALF_DAY -> AmberGold
                                }
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = pillBg
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = pillColor,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = existingAtt.status.name,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = pillColor
                                        )
                                    }
                                }
                            } else {
                                Button(
                                    onClick = {
                                        selectedEmployeeForSelfie = emp
                                        selectedStatus = AttendanceStatus.PRESENT
                                        remarksText = ""
                                        selfieCaptured = false
                                        if (!hasCameraPermission) {
                                            permissionLauncher.launch(Manifest.permission.CAMERA)
                                        } else {
                                            showCameraModal = true
                                        }
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Selfie", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Selfie Capture Modal Dialog (Handles camera simulation & real capture)
    if (showCameraModal && selectedEmployeeForSelfie != null) {
        val emp = selectedEmployeeForSelfie!!
        AlertDialog(
            onDismissRequest = { showCameraModal = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Face, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Selfie Attendance Capture", style = MaterialTheme.typography.titleMedium)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Employee: ${emp.fullName} (${emp.employeeCode})",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Front Camera Preview Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Slate900)
                            .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = if (selfieCaptured) Icons.Default.CheckCircle else Icons.Default.CameraFront,
                                contentDescription = null,
                                tint = if (selfieCaptured) EmeraldPresent else Slate400,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (selfieCaptured) "Selfie Captured & Watermarked!" else "Front Camera Ready",
                                color = if (selfieCaptured) EmeraldPresent else Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${viewModel.todayDate} • ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())}",
                                color = Slate400,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { selfieCaptured = true },
                        colors = ButtonDefaults.buttonColors(containerColor = if (selfieCaptured) EmeraldPresent else MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Camera, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (selfieCaptured) "Retake Selfie" else "Click Selfie")
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Status selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        AttendanceStatus.values().forEach { st ->
                            FilterChip(
                                selected = selectedStatus == st,
                                onClick = { selectedStatus = st },
                                label = { Text(st.name, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = remarksText,
                        onValueChange = { remarksText = it },
                        label = { Text("Remarks (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val selfieUri = if (selfieCaptured) "selfie_${emp.id}_${viewModel.todayDate}.jpg" else ""
                        viewModel.markAttendance(
                            employee = emp,
                            status = selectedStatus,
                            selfieUri = selfieUri,
                            remarks = remarksText
                        )
                        showCameraModal = false
                    }
                ) {
                    Text("Save Attendance")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCameraModal = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
