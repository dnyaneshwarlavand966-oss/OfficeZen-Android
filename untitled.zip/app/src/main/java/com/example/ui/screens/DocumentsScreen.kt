package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.DocumentEntity
import com.example.data.local.DocumentStatus
import com.example.i18n.tr
import com.example.ui.theme.*
import com.example.viewmodel.OfficeZenViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentsScreen(
    viewModel: OfficeZenViewModel,
    onNavigateBack: () -> Unit
) {
    val offices by viewModel.offices.collectAsStateWithLifecycle()
    val departments by viewModel.departments.collectAsStateWithLifecycle()
    val documents by viewModel.allDocuments.collectAsStateWithLifecycle()
    val selectedOfficeId by viewModel.selectedOfficeId.collectAsStateWithLifecycle()

    val filteredDocs = if (selectedOfficeId == 0L) documents else documents.filter { it.officeId == selectedOfficeId }

    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tr("documents"), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Document", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Slate100),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Document Custody & Return",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        )
                        Text(
                            text = "Track handover, expected return & status",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate600
                        )
                    }
                    val pendingCount = filteredDocs.count { it.status == DocumentStatus.PENDING }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (pendingCount > 0) AmberGoldContainer else EmeraldContainer
                    ) {
                        Text(
                            text = "$pendingCount Pending Return",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (pendingCount > 0) AmberGold else EmeraldPresent,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp)
            ) {
                items(filteredDocs) { doc ->
                    val officeName = offices.find { it.id == doc.officeId }?.name ?: ""
                    val isPending = doc.status == DocumentStatus.PENDING

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = doc.documentName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "With: ${doc.personName} (${doc.phone}) • $officeName",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isPending) AmberGoldContainer else EmeraldContainer
                                ) {
                                    Text(
                                        text = doc.status.name,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isPending) AmberGold else EmeraldPresent,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Given: ${doc.handoverDate} • Due Return: ${doc.expectedReturnDate}",
                                style = MaterialTheme.typography.bodySmall
                            )

                            if (isPending) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = { viewModel.returnDocument(doc) },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPresent),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Icon(Icons.Default.AssignmentTurnedIn, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Mark Returned", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddDocumentDialog(
            offices = offices,
            departments = departments,
            onDismiss = { showAddDialog = false },
            onConfirm = { officeId, deptId, name, person, phone, returnDate ->
                viewModel.addDocument(officeId, deptId, name, person, phone, returnDate)
                showAddDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDocumentDialog(
    offices: List<com.example.data.local.OfficeEntity>,
    departments: List<com.example.data.local.DepartmentEntity>,
    onDismiss: () -> Unit,
    onConfirm: (Long, Long, String, String, String, String) -> Unit
) {
    var selectedOfficeId by remember { mutableStateOf(offices.firstOrNull()?.id ?: 1L) }
    var selectedDeptId by remember { mutableStateOf(departments.firstOrNull()?.id ?: 1L) }
    var docName by remember { mutableStateOf("") }
    var personName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var expectedReturnDate by remember { mutableStateOf("2026-11-20") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Document Handover") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = docName,
                    onValueChange = { docName = it },
                    label = { Text("Document / File Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = personName,
                    onValueChange = { personName = it },
                    label = { Text("Handed Over To (Person Name)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Contact Phone") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = expectedReturnDate,
                    onValueChange = { expectedReturnDate = it },
                    label = { Text("Expected Return Date (YYYY-MM-DD)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (docName.isNotEmpty() && personName.isNotEmpty()) {
                        onConfirm(selectedOfficeId, selectedDeptId, docName, personName, phone, expectedReturnDate)
                    }
                },
                enabled = docName.isNotEmpty() && personName.isNotEmpty()
            ) {
                Text("Save Handover")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
