package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.i18n.tr
import com.example.ui.theme.*
import com.example.viewmodel.OfficeZenViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeaCoffeeScreen(
    viewModel: OfficeZenViewModel,
    onNavigateBack: () -> Unit
) {
    val offices by viewModel.offices.collectAsStateWithLifecycle()
    val selectedOfficeId by viewModel.selectedOfficeId.collectAsStateWithLifecycle()
    val recentLogs by viewModel.recentTeaCoffee.collectAsStateWithLifecycle()

    val targetOfficeId = if (selectedOfficeId == 0L) (offices.firstOrNull()?.id ?: 1L) else selectedOfficeId
    val officeName = offices.find { it.id == targetOfficeId }?.name ?: "SJ Office"

    val todayLog = recentLogs.find { it.date == viewModel.todayDate && it.officeId == targetOfficeId }

    var teaCups by remember(todayLog) { mutableStateOf(todayLog?.teaCups ?: 0) }
    var coffeeCups by remember(todayLog) { mutableStateOf(todayLog?.coffeeCups ?: 0) }
    var teaRate by remember(todayLog) { mutableStateOf(todayLog?.teaRate ?: 12.0) }
    var coffeeRate by remember(todayLog) { mutableStateOf(todayLog?.coffeeRate ?: 20.0) }
    var note by remember(todayLog) { mutableStateOf(todayLog?.note ?: "") }

    val currentTotal = (teaCups * teaRate) + (coffeeCups * coffeeRate)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tr("tea_coffee"), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // Header
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = AmberGoldContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Today's Beverage Counter",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        )
                        Text(
                            text = "$officeName • Date: ${viewModel.todayDate}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate700
                        )
                    }
                    Text(
                        text = "₹$currentTotal",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = AmberGold
                    )
                }
            }

            // Interactive Tea Counter
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Tea (चहा)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Rate: ₹${teaRate.toInt()} / cup", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilledIconButton(
                            onClick = { if (teaCups > 0) teaCups-- },
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = Slate100),
                            shape = CircleShape
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Minus", tint = Slate900)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = "$teaCups",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        FilledIconButton(
                            onClick = { teaCups++ },
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = AmberGoldContainer),
                            shape = CircleShape
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Plus", tint = AmberGold)
                        }
                    }
                }
            }

            // Interactive Coffee Counter
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Coffee (कॉफी)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Rate: ₹${coffeeRate.toInt()} / cup", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilledIconButton(
                            onClick = { if (coffeeCups > 0) coffeeCups-- },
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = Slate100),
                            shape = CircleShape
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Minus", tint = Slate900)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = "$coffeeCups",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        FilledIconButton(
                            onClick = { coffeeCups++ },
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = AmberGoldContainer),
                            shape = CircleShape
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Plus", tint = AmberGold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = {
                    viewModel.updateTeaCoffee(
                        officeId = targetOfficeId,
                        teaCups = teaCups,
                        teaRate = teaRate,
                        coffeeCups = coffeeCups,
                        coffeeRate = coffeeRate,
                        note = note
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Save Today's Entry (₹$currentTotal)")
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Recent Daily Records",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
            ) {
                items(recentLogs) { log ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(log.date, fontWeight = FontWeight.Bold)
                                Text("${log.teaCups} Tea (${log.teaRate.toInt()}₹) + ${log.coffeeCups} Coffee (${log.coffeeRate.toInt()}₹)", style = MaterialTheme.typography.bodySmall)
                            }
                            Text("₹${log.totalAmount.toInt()}", fontWeight = FontWeight.Bold, color = AmberGold)
                        }
                    }
                }
            }
        }
    }
}
