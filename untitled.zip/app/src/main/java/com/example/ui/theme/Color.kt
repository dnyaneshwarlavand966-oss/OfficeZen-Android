package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// OfficeZen Executive Palette
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

val ExecutiveNavy = Color(0xFF1E3A8A)
val NavyLight = Color(0xFF2563EB)
val NavyLighter = Color(0xFF3B82F6)

val AmberGold = Color(0xFFD97706)
val AmberGoldLight = Color(0xFFF59E0B)
val AmberGoldContainer = Color(0xFFFEF3C7)

val EmeraldPresent = Color(0xFF10B981)
val EmeraldContainer = Color(0xFFD1FAE5)

val RoseAbsent = Color(0xFFEF4444)
val RoseContainer = Color(0xFFFEE2E2)

val VioletLeave = Color(0xFF8B5CF6)
val VioletContainer = Color(0xFFEDE9FE)
